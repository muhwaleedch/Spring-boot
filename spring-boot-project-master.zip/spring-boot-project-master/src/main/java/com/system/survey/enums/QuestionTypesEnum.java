package com.system.survey.enums;

public enum QuestionTypesEnum {

    text,
    onechoice,
    manychoice,
    file,
    parent_question
}
