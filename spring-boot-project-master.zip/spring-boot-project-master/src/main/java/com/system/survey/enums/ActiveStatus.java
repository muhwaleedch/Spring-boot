package com.system.survey.enums;

public enum ActiveStatus {
    Y, N;
}
