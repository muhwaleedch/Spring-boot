package com.system.survey.dto.survey;

public class IntQuestionsAnsweroptionDto {

    private int intQuestionAnsweroptionId;

    private String intQuestionAnsweroptionAnswer;

    private String intQuestionAnsweroptionIntQuestionId;

    private String intQuestionAnsweroptionIntQuestionUuid;

    private String intQuestionAnsweroptionUuid;

    public int getIntQuestionAnsweroptionId() {
        return intQuestionAnsweroptionId;
    }

    public void setIntQuestionAnsweroptionId(int intQuestionAnsweroptionId) {
        this.intQuestionAnsweroptionId = intQuestionAnsweroptionId;
    }

    public String getIntQuestionAnsweroptionAnswer() {
        return intQuestionAnsweroptionAnswer;
    }

    public void setIntQuestionAnsweroptionAnswer(String intQuestionAnsweroptionAnswer) {
        this.intQuestionAnsweroptionAnswer = intQuestionAnsweroptionAnswer;
    }

    public String getIntQuestionAnsweroptionIntQuestionId() {
        return intQuestionAnsweroptionIntQuestionId;
    }

    public void setIntQuestionAnsweroptionIntQuestionId(String intQuestionAnsweroptionIntQuestionId) {
        this.intQuestionAnsweroptionIntQuestionId = intQuestionAnsweroptionIntQuestionId;
    }

    public String getIntQuestionAnsweroptionIntQuestionUuid() {
        return intQuestionAnsweroptionIntQuestionUuid;
    }

    public void setIntQuestionAnsweroptionIntQuestionUuid(String intQuestionAnsweroptionIntQuestionUuid) {
        this.intQuestionAnsweroptionIntQuestionUuid = intQuestionAnsweroptionIntQuestionUuid;
    }

    public String getIntQuestionAnsweroptionUuid() {
        return intQuestionAnsweroptionUuid;
    }

    public void setIntQuestionAnsweroptionUuid(String intQuestionAnsweroptionUuid) {
        this.intQuestionAnsweroptionUuid = intQuestionAnsweroptionUuid;
    }

}
